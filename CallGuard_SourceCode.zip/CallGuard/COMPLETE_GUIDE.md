# CallGuard — Complete Build Guide
## Everything in one place. Follow top to bottom.

---

## WHAT YOU NEED ON YOUR COMPUTER
- Windows, Mac, or Linux PC
- Internet connection
- ~2 GB free disk space

---

## PART 1 — INSTALL TOOLS (do this once)

### 1A. Install Node.js
Go to https://nodejs.org → download "LTS" version → install it.
After installing, open terminal/command prompt and verify:
```
node --version
```
Should show something like v20.x.x

### 1B. Install Java JDK 17
Go to https://adoptium.net → download JDK 17 → install it.
Verify:
```
java --version
```

### 1C. Install Android Studio
Go to https://developer.android.com/studio → download → install.
During setup, make sure to check:
- ✅ Android SDK
- ✅ Android SDK Platform
- ✅ Android Virtual Device

### 1D. Set environment variables
Add these to your system PATH (search "environment variables" in Windows settings):

ANDROID_HOME = C:\Users\YourName\AppData\Local\Android\Sdk
Add to PATH: %ANDROID_HOME%\platform-tools

On Mac/Linux, add to ~/.bashrc or ~/.zshrc:
```
export ANDROID_HOME=$HOME/Library/Android/sdk
export PATH=$PATH:$ANDROID_HOME/platform-tools
```

### 1E. Install React Native CLI
```
npm install -g react-native-cli
```

---

## PART 2 — CREATE THE PROJECT

Open terminal in a folder where you want the project (e.g. Desktop):

```bash
npx react-native init CallGuard --template react-native-template-typescript
cd CallGuard
```

---

## PART 3 — INSTALL DEPENDENCIES

Run these inside the CallGuard folder:

```bash
npm install @react-native-async-storage/async-storage
npm install react-native-contacts
npm install react-native-audio-recorder-player
npm install react-native-permissions
npm install react-native-vector-icons
```

Then for iOS (skip if Android only):
```bash
cd ios && pod install && cd ..
```

---

## PART 4 — COPY ALL THE FILES

Replace/create each file listed in this guide into your project.
File paths are shown at the top of each section.

---

## PART 5 — RUN ON ANDROID

### Option A: Physical phone (recommended)
1. On your Android phone: Settings → About Phone → tap "Build Number" 7 times
2. Settings → Developer Options → turn on "USB Debugging"
3. Connect phone to PC with USB cable
4. Run:
```bash
npx react-native run-android
```

### Option B: Emulator
1. Open Android Studio → AVD Manager → create a Pixel device with API 33
2. Start the emulator
3. Run:
```bash
npx react-native run-android
```

---

## PART 6 — SPECIAL ANDROID PERMISSION

CallGuard needs to be set as the "Phone" app to screen calls:
1. On your phone: Settings → Apps → Default Apps → Phone App
2. Select CallGuard

This is required for call screening to work.

---

## TROUBLESHOOTING

**"SDK not found"** → Check ANDROID_HOME path is correct

**"Device not found"** → Enable USB Debugging, try different USB cable

**"Build failed"** → Run `cd android && ./gradlew clean && cd ..` then try again

**App installs but calls don't filter** → Make sure CallGuard is set as default Phone app
